package com.mojang.blaze3d.opengl;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.DepthStencilState;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.shaders.UniformType;
import com.mojang.blaze3d.systems.CommandEncoderBackend;
import com.mojang.blaze3d.systems.GpuQuery;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderPassBackend;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.logging.LogUtils;
import java.lang.runtime.SwitchBootstraps;
import java.nio.ByteBuffer;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.Map.Entry;
import java.util.function.BiConsumer;
import java.util.function.Supplier;
import net.minecraft.util.ARGB;
import org.jspecify.annotations.Nullable;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL11C;
import org.lwjgl.opengl.GL31;
import org.lwjgl.opengl.GL32;
import org.lwjgl.opengl.GL32C;
import org.lwjgl.opengl.GL33C;
import org.slf4j.Logger;

class GlCommandEncoder implements CommandEncoderBackend {
   private static final Logger LOGGER = LogUtils.getLogger();
   private final GlDevice device;
   private final int readFbo;
   private final int drawFbo;
   @Nullable
   private RenderPipeline lastPipeline;
   private boolean inRenderPass;
   @Nullable
   private GlProgram lastProgram;
   @Nullable
   private GlTimerQuery activeTimerQuery;

   protected GlCommandEncoder(final GlDevice device) {
      this.device = device;
      this.readFbo = device.directStateAccess().createFrameBufferObject();
      this.drawFbo = device.directStateAccess().createFrameBufferObject();
   }

   @Override
   public RenderPassBackend createRenderPass(final Supplier<String> label, final GpuTextureView colorTexture, final OptionalInt clearColor) {
      return this.createRenderPass(label, colorTexture, clearColor, null, OptionalDouble.empty());
   }

   @Override
   public RenderPassBackend createRenderPass(
      final Supplier<String> label,
      final GpuTextureView colorTexture,
      final OptionalInt clearColor,
      @Nullable final GpuTextureView depthTexture,
      final OptionalDouble clearDepth
   ) {
      this.inRenderPass = true;
      this.device.debugLabels().pushDebugGroup(label);
      int fbo = ((GlTextureView)colorTexture).getFbo(this.device.directStateAccess(), depthTexture == null ? null : depthTexture.texture());
      GlStateManager._glBindFramebuffer(36160, fbo);
      int clearMask = 0;
      if (clearColor.isPresent()) {
         int argb = clearColor.getAsInt();
         GL11.glClearColor(ARGB.redFloat(argb), ARGB.greenFloat(argb), ARGB.blueFloat(argb), ARGB.alphaFloat(argb));
         clearMask |= 16384;
      }

      if (depthTexture != null && clearDepth.isPresent()) {
         GL11.glClearDepth(clearDepth.getAsDouble());
         clearMask |= 256;
      }

      if (clearMask != 0) {
         GlStateManager._disableScissorTest();
         GlStateManager._depthMask(true);
         GlStateManager._colorMask(15);
         GlStateManager._clear(clearMask);
      }

      GlStateManager._viewport(0, 0, colorTexture.getWidth(0), colorTexture.getHeight(0));
      this.lastPipeline = null;
      return new GlRenderPass(this, this.device, depthTexture != null);
   }

   @Override
   public boolean isInRenderPass() {
      return this.inRenderPass;
   }

   @Override
   public void clearColorTexture(final GpuTexture colorTexture, final int clearColor) {
      this.device.directStateAccess().bindFrameBufferTextures(this.drawFbo, ((GlTexture)colorTexture).id, 0, 0, 36160);
      GL11.glClearColor(ARGB.redFloat(clearColor), ARGB.greenFloat(clearColor), ARGB.blueFloat(clearColor), ARGB.alphaFloat(clearColor));
      GlStateManager._disableScissorTest();
      GlStateManager._colorMask(15);
      GlStateManager._clear(16384);
      GlStateManager._glFramebufferTexture2D(36160, 36064, 3553, 0, 0);
      GlStateManager._glBindFramebuffer(36160, 0);
   }

   @Override
   public void clearColorAndDepthTextures(final GpuTexture colorTexture, final int clearColor, final GpuTexture depthTexture, final double clearDepth) {
      int fbo = ((GlTexture)colorTexture).getFbo(this.device.directStateAccess(), depthTexture);
      GlStateManager._glBindFramebuffer(36160, fbo);
      GlStateManager._disableScissorTest();
      GL11.glClearDepth(clearDepth);
      GL11.glClearColor(ARGB.redFloat(clearColor), ARGB.greenFloat(clearColor), ARGB.blueFloat(clearColor), ARGB.alphaFloat(clearColor));
      GlStateManager._depthMask(true);
      GlStateManager._colorMask(15);
      GlStateManager._clear(16640);
      GlStateManager._glBindFramebuffer(36160, 0);
   }

   @Override
   public void clearColorAndDepthTextures(
      final GpuTexture colorTexture,
      final int clearColor,
      final GpuTexture depthTexture,
      final double clearDepth,
      final int regionX,
      final int regionY,
      final int regionWidth,
      final int regionHeight
   ) {
      int fbo = ((GlTexture)colorTexture).getFbo(this.device.directStateAccess(), depthTexture);
      GlStateManager._glBindFramebuffer(36160, fbo);
      GlStateManager._scissorBox(regionX, regionY, regionWidth, regionHeight);
      GlStateManager._enableScissorTest();
      GL11.glClearDepth(clearDepth);
      GL11.glClearColor(ARGB.redFloat(clearColor), ARGB.greenFloat(clearColor), ARGB.blueFloat(clearColor), ARGB.alphaFloat(clearColor));
      GlStateManager._depthMask(true);
      GlStateManager._colorMask(15);
      GlStateManager._clear(16640);
      GlStateManager._glBindFramebuffer(36160, 0);
   }

   @Override
   public void clearDepthTexture(final GpuTexture depthTexture, final double clearDepth) {
      this.device.directStateAccess().bindFrameBufferTextures(this.drawFbo, 0, ((GlTexture)depthTexture).id, 0, 36160);
      GL11.glDrawBuffer(0);
      GL11.glClearDepth(clearDepth);
      GlStateManager._depthMask(true);
      GlStateManager._disableScissorTest();
      GlStateManager._clear(256);
      GL11.glDrawBuffer(36064);
      GlStateManager._glFramebufferTexture2D(36160, 36096, 3553, 0, 0);
      GlStateManager._glBindFramebuffer(36160, 0);
   }

   @Override
   public void writeToBuffer(final GpuBufferSlice slice, final ByteBuffer data) {
      GlBuffer buffer = (GlBuffer)slice.buffer();
      if (buffer.closed) {
         throw new IllegalStateException("Buffer already closed");
      } else if ((buffer.usage() & 8) == 0) {
         throw new IllegalStateException("Buffer needs USAGE_COPY_DST to be a destination for a copy");
      } else {
         int length = data.remaining();
         if ((long)length > slice.length()) {
            throw new IllegalArgumentException(
               "Cannot write more data than the slice allows (attempting to write " + length + " bytes into a slice of length " + slice.length() + ")"
            );
         } else if (slice.length() + slice.offset() > buffer.size()) {
            throw new IllegalArgumentException(
               "Cannot write more data than this buffer can hold (attempting to write "
                  + length
                  + " bytes at offset "
                  + slice.offset()
                  + " to "
                  + buffer.size()
                  + " size buffer)"
            );
         } else {
            this.device.directStateAccess().bufferSubData(buffer.handle, slice.offset(), data, buffer.usage());
         }
      }
   }

   @Override
   public GpuBuffer.MappedView mapBuffer(final GpuBufferSlice slice, final boolean read, final boolean write) {
      GlBuffer buffer = (GlBuffer)slice.buffer();
      int flags = 0;
      if (read) {
         flags |= 1;
      }

      if (write) {
         flags |= 34;
      }

      return this.device.getBufferStorage().mapBuffer(this.device.directStateAccess(), buffer, slice.offset(), slice.length(), flags);
   }

   @Override
   public void copyToBuffer(final GpuBufferSlice source, final GpuBufferSlice target) {
      GlBuffer sourceBuffer = (GlBuffer)source.buffer();
      GlBuffer targetBuffer = (GlBuffer)target.buffer();
      this.device.directStateAccess().copyBufferSubData(sourceBuffer.handle, targetBuffer.handle, source.offset(), target.offset(), source.length());
   }

   @Override
   public void writeToTexture(
      final GpuTexture destination,
      final NativeImage source,
      final int mipLevel,
      final int depthOrLayer,
      final int destX,
      final int destY,
      final int width,
      final int height,
      final int sourceX,
      final int sourceY
   ) {
      int target;
      if ((destination.usage() & 16) != 0) {
         target = GlConst.CUBEMAP_TARGETS[depthOrLayer % 6];
         GL11.glBindTexture(34067, ((GlTexture)destination).id);
      } else {
         target = 3553;
         GlStateManager._bindTexture(((GlTexture)destination).id);
      }

      GlStateManager._pixelStore(3314, source.getWidth());
      GlStateManager._pixelStore(3316, sourceX);
      GlStateManager._pixelStore(3315, sourceY);
      GlStateManager._pixelStore(3317, source.format().components());
      GlStateManager._texSubImage2D(target, mipLevel, destX, destY, width, height, GlConst.toGl(source.format()), 5121, source.getPointer());
   }

   @Override
   public void writeToTexture(
      final GpuTexture destination,
      final ByteBuffer source,
      final NativeImage.Format format,
      final int mipLevel,
      final int depthOrLayer,
      final int destX,
      final int destY,
      final int width,
      final int height
   ) {
      int target;
      if ((destination.usage() & 16) != 0) {
         target = GlConst.CUBEMAP_TARGETS[depthOrLayer % 6];
         GL11.glBindTexture(34067, ((GlTexture)destination).id);
      } else {
         target = 3553;
         GlStateManager._bindTexture(((GlTexture)destination).id);
      }

      GlStateManager._pixelStore(3314, width);
      GlStateManager._pixelStore(3316, 0);
      GlStateManager._pixelStore(3315, 0);
      GlStateManager._pixelStore(3317, format.components());
      GlStateManager._texSubImage2D(target, mipLevel, destX, destY, width, height, GlConst.toGl(format), 5121, source);
   }

   @Override
   public void copyTextureToBuffer(final GpuTexture source, final GpuBuffer destination, final long offset, final Runnable callback, final int mipLevel) {
      this.copyTextureToBuffer(source, destination, offset, callback, mipLevel, 0, 0, source.getWidth(mipLevel), source.getHeight(mipLevel));
   }

   @Override
   public void copyTextureToBuffer(
      final GpuTexture source,
      final GpuBuffer destination,
      final long offset,
      final Runnable callback,
      final int mipLevel,
      final int x,
      final int y,
      final int width,
      final int height
   ) {
      GlStateManager.clearGlErrors();
      this.device.directStateAccess().bindFrameBufferTextures(this.readFbo, ((GlTexture)source).glId(), 0, mipLevel, 36008);
      GlStateManager._glBindBuffer(35051, ((GlBuffer)destination).handle);
      GlStateManager._pixelStore(3330, width);
      GlStateManager._readPixels(x, y, width, height, GlConst.toGlExternalId(source.getFormat()), GlConst.toGlType(source.getFormat()), offset);
      RenderSystem.queueFencedTask(callback);
      GlStateManager._glFramebufferTexture2D(36008, 36064, 3553, 0, mipLevel);
      GlStateManager._glBindFramebuffer(36008, 0);
      GlStateManager._glBindBuffer(35051, 0);
      int error = GlStateManager._getError();
      if (error != 0) {
         throw new IllegalStateException("Couldn't perform copyTobuffer for texture " + source.getLabel() + ": GL error " + error);
      }
   }

   @Override
   public void copyTextureToTexture(
      final GpuTexture source,
      final GpuTexture destination,
      final int mipLevel,
      final int destX,
      final int destY,
      final int sourceX,
      final int sourceY,
      final int width,
      final int height
   ) {
      GlStateManager.clearGlErrors();
      GlStateManager._disableScissorTest();
      boolean isDepth = source.getFormat().hasDepthAspect();
      int sourceId = ((GlTexture)source).glId();
      int destId = ((GlTexture)destination).glId();
      this.device.directStateAccess().bindFrameBufferTextures(this.readFbo, isDepth ? 0 : sourceId, isDepth ? sourceId : 0, 0, 0);
      this.device.directStateAccess().bindFrameBufferTextures(this.drawFbo, isDepth ? 0 : destId, isDepth ? destId : 0, 0, 0);
      this.device
         .directStateAccess()
         .blitFrameBuffers(this.readFbo, this.drawFbo, sourceX, sourceY, width, height, destX, destY, width, height, isDepth ? 256 : 16384, 9728);
      int error = GlStateManager._getError();
      if (error != 0) {
         throw new IllegalStateException(
            "Couldn't perform copyToTexture for texture " + source.getLabel() + " to " + destination.getLabel() + ": GL error " + error
         );
      }
   }

   @Override
   public void presentTexture(final GpuTextureView textureView) {
      GlStateManager._disableScissorTest();
      GlStateManager._viewport(0, 0, textureView.getWidth(0), textureView.getHeight(0));
      GlStateManager._depthMask(true);
      GlStateManager._colorMask(15);
      this.device.directStateAccess().bindFrameBufferTextures(this.drawFbo, ((GlTexture)textureView.texture()).glId(), 0, 0, 0);
      this.device
         .directStateAccess()
         .blitFrameBuffers(
            this.drawFbo, 0, 0, 0, textureView.getWidth(0), textureView.getHeight(0), 0, 0, textureView.getWidth(0), textureView.getHeight(0), 16384, 9728
         );
   }

   @Override
   public GpuFence createFence() {
      return new GlFence();
   }

   protected <T> void executeDrawMultiple(
      final GlRenderPass renderPass,
      final Collection<RenderPass.Draw<T>> draws,
      @Nullable final GpuBuffer defaultIndexBuffer,
      @Nullable VertexFormat.IndexType defaultIndexType,
      final Collection<String> dynamicUniforms,
      final T uniformArgument
   ) {
      if (this.trySetup(renderPass, dynamicUniforms)) {
         if (defaultIndexType == null) {
            defaultIndexType = VertexFormat.IndexType.SHORT;
         }

         for (RenderPass.Draw<T> draw : draws) {
            VertexFormat.IndexType indexType = draw.indexType() == null ? defaultIndexType : draw.indexType();
            renderPass.setIndexBuffer(draw.indexBuffer() == null ? defaultIndexBuffer : draw.indexBuffer(), indexType);
            renderPass.setVertexBuffer(draw.slot(), draw.vertexBuffer());
            if (GlRenderPass.VALIDATION) {
               if (renderPass.indexBuffer == null) {
                  throw new IllegalStateException("Missing index buffer");
               }

               if (renderPass.indexBuffer.isClosed()) {
                  throw new IllegalStateException("Index buffer has been closed!");
               }

               if (renderPass.vertexBuffers[0] == null) {
                  throw new IllegalStateException("Missing vertex buffer at slot 0");
               }

               if (renderPass.vertexBuffers[0].isClosed()) {
                  throw new IllegalStateException("Vertex buffer at slot 0 has been closed!");
               }
            }

            BiConsumer<T, RenderPass.UniformUploader> uniformUploaderConsumer = draw.uniformUploaderConsumer();
            if (uniformUploaderConsumer != null) {
               uniformUploaderConsumer.accept(uniformArgument, (name, buffer) -> {
                  if (renderPass.pipeline.program().getUniform(name) instanceof Uniform.Ubo $b$0) {
                     Uniform.Ubo var10000 = $b$0;

                     try {
                        var9x = var10000.blockBinding();
                     } catch (Throwable var8x) {
                        throw new MatchException(var8x.toString(), var8x);
                     }

                     int patt2$temp = var9x;
                     if (true) {
                        GL32.glBindBufferRange(35345, patt2$temp, ((GlBuffer)buffer.buffer()).handle, buffer.offset(), buffer.length());
                     }
                  }
               });
            }

            this.drawFromBuffers(renderPass, draw.baseVertex(), draw.firstIndex(), draw.indexCount(), indexType, renderPass.pipeline, 1);
         }
      }
   }

   protected void executeDraw(
      final GlRenderPass renderPass,
      final int baseVertex,
      final int firstIndex,
      final int drawCount,
      @Nullable final VertexFormat.IndexType indexType,
      final int instanceCount
   ) {
      if (this.trySetup(renderPass, Collections.emptyList())) {
         if (GlRenderPass.VALIDATION) {
            if (indexType != null) {
               if (renderPass.indexBuffer == null) {
                  throw new IllegalStateException("Missing index buffer");
               }

               if (renderPass.indexBuffer.isClosed()) {
                  throw new IllegalStateException("Index buffer has been closed!");
               }

               if ((renderPass.indexBuffer.usage() & 64) == 0) {
                  throw new IllegalStateException("Index buffer must have GpuBuffer.USAGE_INDEX!");
               }
            }

            GlRenderPipeline pipeline = renderPass.pipeline;
            if (renderPass.vertexBuffers[0] == null && pipeline != null && !pipeline.info().getVertexFormat().getElements().isEmpty()) {
               throw new IllegalStateException("Vertex format contains elements but vertex buffer at slot 0 is null");
            }

            if (renderPass.vertexBuffers[0] != null && renderPass.vertexBuffers[0].isClosed()) {
               throw new IllegalStateException("Vertex buffer at slot 0 has been closed!");
            }

            if (renderPass.vertexBuffers[0] != null && (renderPass.vertexBuffers[0].usage() & 32) == 0) {
               throw new IllegalStateException("Vertex buffer must have GpuBuffer.USAGE_VERTEX!");
            }
         }

         this.drawFromBuffers(renderPass, baseVertex, firstIndex, drawCount, indexType, renderPass.pipeline, instanceCount);
      }
   }

   private void drawFromBuffers(
      final GlRenderPass renderPass,
      final int baseVertex,
      final int firstIndex,
      final int drawCount,
      @Nullable final VertexFormat.IndexType indexType,
      final GlRenderPipeline pipeline,
      final int instanceCount
   ) {
      this.device.vertexArrayCache().bindVertexArray(pipeline.info().getVertexFormat(), (GlBuffer)renderPass.vertexBuffers[0]);
      if (indexType != null) {
         GlStateManager._glBindBuffer(34963, ((GlBuffer)renderPass.indexBuffer).handle);
         if (instanceCount > 1) {
            if (baseVertex > 0) {
               GL32.glDrawElementsInstancedBaseVertex(
                  GlConst.toGl(pipeline.info().getVertexFormatMode()),
                  drawCount,
                  GlConst.toGl(indexType),
                  (long)firstIndex * (long)indexType.bytes,
                  instanceCount,
                  baseVertex
               );
            } else {
               GL31.glDrawElementsInstanced(
                  GlConst.toGl(pipeline.info().getVertexFormatMode()),
                  drawCount,
                  GlConst.toGl(indexType),
                  (long)firstIndex * (long)indexType.bytes,
                  instanceCount
               );
            }
         } else if (baseVertex > 0) {
            GL32.glDrawElementsBaseVertex(
               GlConst.toGl(pipeline.info().getVertexFormatMode()), drawCount, GlConst.toGl(indexType), (long)firstIndex * (long)indexType.bytes, baseVertex
            );
         } else {
            GlStateManager._drawElements(
               GlConst.toGl(pipeline.info().getVertexFormatMode()), drawCount, GlConst.toGl(indexType), (long)firstIndex * (long)indexType.bytes
            );
         }
      } else if (instanceCount > 1) {
         GL31.glDrawArraysInstanced(GlConst.toGl(pipeline.info().getVertexFormatMode()), baseVertex, drawCount, instanceCount);
      } else {
         GlStateManager._drawArrays(GlConst.toGl(pipeline.info().getVertexFormatMode()), baseVertex, drawCount);
      }
   }

   // $VF: Inserted dummy exception handlers to handle obfuscated exceptions
   private boolean trySetup(final GlRenderPass renderPass, final Collection<String> dynamicUniforms) {
      if (GlRenderPass.VALIDATION) {
         if (renderPass.pipeline == null) {
            throw new IllegalStateException("Can't draw without a render pipeline");
         }

         if (renderPass.pipeline.program() == GlProgram.INVALID_PROGRAM) {
            throw new IllegalStateException("Pipeline contains invalid shader program");
         }

         for (RenderPipeline.UniformDescription uniform : renderPass.pipeline.info().getUniforms()) {
            GpuBufferSlice value = renderPass.uniforms.get(uniform.name());
            if (!dynamicUniforms.contains(uniform.name())) {
               if (value == null) {
                  throw new IllegalStateException("Missing uniform " + uniform.name() + " (should be " + uniform.type() + ")");
               }

               if (uniform.type() == UniformType.UNIFORM_BUFFER) {
                  if (value.buffer().isClosed()) {
                     throw new IllegalStateException("Uniform buffer " + uniform.name() + " is already closed");
                  }

                  if ((value.buffer().usage() & 128) == 0) {
                     throw new IllegalStateException("Uniform buffer " + uniform.name() + " must have GpuBuffer.USAGE_UNIFORM");
                  }
               }

               if (uniform.type() == UniformType.TEXEL_BUFFER) {
                  if (value.offset() != 0L || value.length() != value.buffer().size()) {
                     throw new IllegalStateException("Uniform texel buffers do not support a slice of a buffer, must be entire buffer");
                  }

                  if (uniform.textureFormat() == null) {
                     throw new IllegalStateException("Invalid uniform texel buffer " + uniform.name() + " (missing a texture format)");
                  }
               }
            }
         }

         for (Entry<String, Uniform> entry : renderPass.pipeline.program().getUniforms().entrySet()) {
            if (entry.getValue() instanceof Uniform.Sampler) {
               String name = entry.getKey();
               GlRenderPass.TextureViewAndSampler viewAndSampler = renderPass.samplers.get(name);
               if (viewAndSampler == null) {
                  throw new IllegalStateException("Missing sampler " + name);
               }

               GlTextureView textureView = viewAndSampler.view();
               if (textureView.isClosed()) {
                  throw new IllegalStateException("Texture view " + name + " (" + textureView.texture().getLabel() + ") has been closed!");
               }

               if ((textureView.texture().usage() & 4) == 0) {
                  throw new IllegalStateException("Texture view " + name + " (" + textureView.texture().getLabel() + ") must have USAGE_TEXTURE_BINDING!");
               }

               if (viewAndSampler.sampler().isClosed()) {
                  throw new IllegalStateException("Sampler for " + name + " (" + textureView.texture().getLabel() + ") has been closed!");
               }
            }
         }

         if (renderPass.pipeline.info().wantsDepthTexture() && !renderPass.hasDepthTexture()) {
            LOGGER.warn("Render pipeline {} wants a depth texture but none was provided - this is probably a bug", renderPass.pipeline.info().getLocation());
         }
      } else if (renderPass.pipeline == null || renderPass.pipeline.program() == GlProgram.INVALID_PROGRAM) {
         return false;
      }

      RenderPipeline pipeline = renderPass.pipeline.info();
      GlProgram glProgram = renderPass.pipeline.program();
      this.applyPipelineState(pipeline);
      boolean differentProgram = this.lastProgram != glProgram;
      if (differentProgram) {
         GlStateManager._glUseProgram(glProgram.getProgramId());
         this.lastProgram = glProgram;
      }

      label206:
      for (Entry<String, Uniform> entryx : glProgram.getUniforms().entrySet()) {
         String namex = entryx.getKey();
         boolean isDirty = renderPass.dirtyUniforms.contains(namex);
         Uniform var10000 = entryx.getValue();
         Objects.requireNonNull(var10000);
         Uniform var10 = var10000;
         byte var11 = 0;

         while (true) {
            label202:
            while (true) {
               Throwable var52;
               switch (SwitchBootstraps.typeSwitch<"typeSwitch",Uniform.Ubo,Uniform.Utb,Uniform.Sampler>(var10, var11)) {
                  case 0:
                     Uniform.Ubo var12 = (Uniform.Ubo)var10;
                     Uniform.Ubo var64 = var12;

                     try {
                        var65 = var64.blockBinding();
                     } catch (Throwable var32) {
                        var52 = var32;
                        boolean var71 = false;
                        break;
                     }

                     int var42 = var65;
                     if (true) {
                        if (isDirty) {
                           GpuBufferSlice bufferView = renderPass.uniforms.get(namex);
                           GL32.glBindBufferRange(35345, var42, ((GlBuffer)bufferView.buffer()).handle, bufferView.offset(), bufferView.length());
                        }
                        continue label206;
                     }

                     var11 = 1;
                     continue;
                  case 1:
                     Uniform.Utb bufferView = (Uniform.Utb)var10;
                     Uniform.Utb var56 = bufferView;

                     try {
                        var57 = var56.location();
                     } catch (Throwable var31) {
                        var52 = var31;
                        boolean var67 = false;
                        break;
                     }

                     int var44 = var57;
                     if (true) {
                        Uniform.Utb var58 = bufferView;

                        try {
                           var59 = var58.samplerIndex();
                        } catch (Throwable var30) {
                           var52 = var30;
                           boolean var68 = false;
                           break;
                        }

                        var44 = var59;
                        if (true) {
                           Uniform.Utb var60 = bufferView;

                           try {
                              var61 = var60.format();
                           } catch (Throwable var29) {
                              var52 = var29;
                              boolean var69 = false;
                              break;
                           }

                           TextureFormat var46 = var61;
                           Uniform.Utb var62 = bufferView;

                           try {
                              var63 = var62.texture();
                           } catch (Throwable var28) {
                              var52 = var28;
                              boolean var70 = false;
                              break;
                           }

                           var44 = var63;
                           if (true) {
                              if (differentProgram || isDirty) {
                                 GlStateManager._glUniform1i(var44, var44);
                              }

                              GlStateManager._activeTexture(33984 + var44);
                              GL11C.glBindTexture(35882, var44);
                              if (isDirty) {
                                 GpuBufferSlice bufferViewx = renderPass.uniforms.get(namex);
                                 GL31.glTexBuffer(35882, GlConst.toGlInternalId(var46), ((GlBuffer)bufferViewx.buffer()).handle);
                              }
                              continue label206;
                           }
                        }
                     }

                     var11 = 2;
                     continue;
                  case 2:
                     Uniform.Sampler bufferView = (Uniform.Sampler)var10;
                     Uniform.Sampler var51 = bufferView;

                     try {
                        var53 = var51.location();
                     } catch (Throwable var27) {
                        var52 = var27;
                        boolean var10001 = false;
                        break;
                     }

                     int viewAndSamplerx = var53;
                     if (false) {
                        break label202;
                     }

                     Uniform.Sampler var54 = bufferView;

                     try {
                        var55 = var54.samplerIndex();
                     } catch (Throwable var26) {
                        var52 = var26;
                        boolean var66 = false;
                        break;
                     }

                     viewAndSamplerx = var55;
                     if (true) {
                        GlRenderPass.TextureViewAndSampler viewAndSamplerxx = renderPass.samplers.get(namex);
                        if (viewAndSamplerxx == null) {
                           continue label206;
                        }

                        GlTextureView textureViewx = viewAndSamplerxx.view();
                        if (differentProgram || isDirty) {
                           GlStateManager._glUniform1i(viewAndSamplerx, viewAndSamplerx);
                        }

                        GlStateManager._activeTexture(33984 + viewAndSamplerx);
                        GlTexture texture = textureViewx.texture();
                        int target;
                        if ((texture.usage() & 16) != 0) {
                           target = 34067;
                           GL11.glBindTexture(34067, texture.id);
                        } else {
                           target = 3553;
                           GlStateManager._bindTexture(texture.id);
                        }

                        GL33C.glBindSampler(viewAndSamplerx, viewAndSamplerxx.sampler().getId());
                        GlStateManager._texParameter(target, 33084, textureViewx.baseMipLevel());
                        GlStateManager._texParameter(target, 33085, textureViewx.baseMipLevel() + textureViewx.mipLevels() - 1);
                        continue label206;
                     }
                     break label202;
                  default:
                     throw new MatchException(null, null);
               }

               Throwable var40 = var52;
               throw new MatchException(var40.toString(), var40);
            }

            var11 = 3;
         }
      }

      renderPass.dirtyUniforms.clear();
      if (renderPass.isScissorEnabled()) {
         GlStateManager._enableScissorTest();
         GlStateManager._scissorBox(renderPass.getScissorX(), renderPass.getScissorY(), renderPass.getScissorWidth(), renderPass.getScissorHeight());
      } else {
         GlStateManager._disableScissorTest();
      }

      return true;
   }

   private void applyPipelineState(final RenderPipeline pipeline) {
      if (this.lastPipeline != pipeline) {
         this.lastPipeline = pipeline;
         DepthStencilState depthStencilState = pipeline.getDepthStencilState();
         if (depthStencilState != null) {
            GlStateManager._enableDepthTest();
            GlStateManager._depthFunc(GlConst.toGl(depthStencilState.depthTest()));
            GlStateManager._depthMask(depthStencilState.writeDepth());
            if (depthStencilState.depthBiasConstant() == 0.0F && depthStencilState.depthBiasScaleFactor() == 0.0F) {
               GlStateManager._disablePolygonOffset();
            } else {
               GlStateManager._polygonOffset(depthStencilState.depthBiasScaleFactor(), depthStencilState.depthBiasConstant());
               GlStateManager._enablePolygonOffset();
            }
         } else {
            GlStateManager._disableDepthTest();
            GlStateManager._depthMask(false);
            GlStateManager._disablePolygonOffset();
         }

         if (pipeline.isCull()) {
            GlStateManager._enableCull();
         } else {
            GlStateManager._disableCull();
         }

         if (pipeline.getColorTargetState().blendFunction().isPresent()) {
            GlStateManager._enableBlend();
            BlendFunction blendFunction = pipeline.getColorTargetState().blendFunction().get();
            GlStateManager._blendFuncSeparate(
               GlConst.toGl(blendFunction.sourceColor()),
               GlConst.toGl(blendFunction.destColor()),
               GlConst.toGl(blendFunction.sourceAlpha()),
               GlConst.toGl(blendFunction.destAlpha())
            );
         } else {
            GlStateManager._disableBlend();
         }

         GlStateManager._polygonMode(1032, GlConst.toGl(pipeline.getPolygonMode()));
         GlStateManager._colorMask(pipeline.getColorTargetState().writeMask());
      }
   }

   public void finishRenderPass() {
      this.inRenderPass = false;
      GlStateManager._glBindFramebuffer(36160, 0);
      this.device.debugLabels().popDebugGroup();
   }

   @Override
   public GpuQuery timerQueryBegin() {
      RenderSystem.assertOnRenderThread();
      if (this.activeTimerQuery != null) {
         throw new IllegalStateException("A GL_TIME_ELAPSED query is already active");
      } else {
         int queryId = GL32C.glGenQueries();
         GL32C.glBeginQuery(35007, queryId);
         this.activeTimerQuery = new GlTimerQuery(queryId);
         return this.activeTimerQuery;
      }
   }

   @Override
   public void timerQueryEnd(final GpuQuery query) {
      RenderSystem.assertOnRenderThread();
      if (query != this.activeTimerQuery) {
         throw new IllegalStateException("Mismatched or duplicate GpuQuery when ending timerQuery");
      } else {
         GL32C.glEndQuery(35007);
         this.activeTimerQuery = null;
      }
   }
}
